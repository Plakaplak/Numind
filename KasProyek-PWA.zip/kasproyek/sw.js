/* KasProyek service worker — aplikasi bisa dibuka dan dipakai sepenuhnya offline.
   Strategi: cache-first untuk berkas aplikasi (stale-while-revalidate di latar),
   dengan fallback ke index.html untuk navigasi. Data pengguna ada di IndexedDB, bukan di cache. */
const VERSION = 'kasproyek-v1.1.0';
const ASSETS = [
  './', './index.html', './manifest.webmanifest',
  './css/app.css',
  './js/core.js', './js/db.js', './js/ui.js', './js/shared.js',
  './js/views-dashboard.js', './js/views-input.js', './js/views-claims.js', './js/views-report.js', './js/app.js',
  './img/numind-gold.png', './img/numind-green.png', './img/numind-black.png', './img/numind-mark.svg',
  './icons/icon.svg', './icons/icon-192.png', './icons/icon-512.png', './icons/icon-maskable-512.png', './icons/apple-touch-icon.png', './icons/favicon-32.png'
];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(VERSION).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k.startsWith('kasproyek-') && k !== VERSION).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  if (req.mode === 'navigate') {
    e.respondWith(
      caches.match('./index.html').then(cached => {
        const net = fetch(req).then(res => { if (res && res.ok) caches.open(VERSION).then(c => c.put('./index.html', res.clone())); return res; }).catch(() => null);
        return cached || net.then(r => r || new Response('Offline', { status: 503, headers: { 'Content-Type': 'text/plain' } }));
      })
    );
    return;
  }

  e.respondWith(
    caches.match(req, { ignoreSearch: true }).then(cached => {
      const net = fetch(req).then(res => {
        if (res && res.ok && res.type === 'basic') { const copy = res.clone(); caches.open(VERSION).then(c => c.put(req, copy)); }
        return res;
      }).catch(() => null);
      return cached || net.then(r => r || new Response('', { status: 504 }));
    })
  );
});
